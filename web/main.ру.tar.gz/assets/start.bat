@echo off
chcp 65001 >nul
cd /d "%~dp0"
python --version >nul 2>&1
if errorlevel 1 (
    echo Python не найден. Установи его с https://www.python.org/downloads/
    echo и при установке поставь галочку "Add Python to PATH".
    pause
    exit /b
)
echo Ставлю нужные библиотеки (первый раз нужен интернет)...
python -m pip install -r requirements.txt
echo Запускаю игру...
python chekunets.py
pause
