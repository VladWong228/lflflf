@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem Делает из игры Chekunets.exe, чтобы другу не нужен был Python.
python -m pip install -r requirements.txt pyinstaller
python -m PyInstaller --noconfirm --onedir --windowed --name Chekunets chekunets.py
rem Картинки, звуки и видео кладём рядом с exe
for %%D in (bomj1 bomj2 bomj3 bomj4 bomj5 cameras sounds) do (
    if exist "%%D" xcopy /E /I /Y "%%D" "dist\Chekunets\%%D" >nul
)
for %%E in (png wav mp4 ogg mp3 jpg) do (
    copy /Y "*.%%E" "dist\Chekunets\" >nul 2>&1
)
echo.
echo Готово! Папка dist\Chekunets - её можно заархивировать и отправить другу.
echo Друг запускает Chekunets.exe.
pause
