import pygame
import random
import os
import sys

# Pygame initialization
pygame.init()
pygame.mixer.init()

# Screen constants
WIDTH, HEIGHT = 1280, 720
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("5 Nights at Chekun's")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (200, 30, 30)
GREEN = (30, 200, 30)
BLUE = (30, 100, 200)
YELLOW = (220, 220, 30)
GRAY = (100, 100, 100)
DARK_GRAY = (40, 40, 40)

# Fonts
font = pygame.font.SysFont("Arial", 28)
title_font = pygame.font.SysFont("Arial", 48, bold=True)
cam_font = pygame.font.SysFont("Arial", 20, bold=True)

# Game states: "menu", "game", "corridor", "cameras", "panel", "game_over", "win_video", "between_nights"
game_state = "menu"
current_night = 1

# Game variables
clock = pygame.time.Clock()
hours_passed = 0
night_timer = 0.0
battery = 100.0
power_out = False

# Door and Chekun
door_health = 100.0
chekun_rect = pygame.Rect(WIDTH // 2 - 80, HEIGHT // 2 - 40, 160, 80)

# Bum 1 (at the door)
bomzh_active = False
bomzh_timer = 0.0
next_bomzh_time = random.randint(15000, 30000)
current_frame_index = 0

# Bum 2 (cam wanderer)
BOMZH2_FROM_NIGHT = 2
bomzh2_active = False
bomzh2_timer = 0.0
next_bomzh2_time = random.randint(20000, 40000)
bomzh2_path = ["CAM 1", "CAM 3", "CAM 4", "CAM 6"]
bomzh2_path_index = 0
current_bomzh2_cam = "CAM 1"
steal_timer_2 = 0.0
max_steal_time = 8000.0

# Bum 3 (corridor)
BOMZH3_FROM_NIGHT = 2
bomzh3_active = False
bomzh3_timer = 0.0
next_bomzh3_time = random.randint(25000, 45000)
bomzh3_progress = 0.0
bomzh3_scare = 0.0
SCARE_MS = 2000.0

# Bum 4 ("Quiet")
BOMZH4_FROM_NIGHT = 3
bomzh4_active = False
bomzh4_timer = 0.0
next_bomzh4_time = random.randint(30000, 50000)
BOMZH4_ROUTE = ["CAM 2", "CAM 5", "CAM 6"]
bomzh4_index = 0
bomzh4_move_timer = 0.0
bomzh4_door_timer = 0.0

def bomzh4_cam():
    if bomzh4_index < len(BOMZH4_ROUTE):
        return BOMZH4_ROUTE[bomzh4_index]
    return BOMZH4_ROUTE[-1]

def bomzh4_move_ms():
    return max(3000, 10000 - (current_night * 1200))

def bomzh4_door_ms():
    return max(4000, 12000 - (current_night * 1500))

# Bum 5 ("Listener")
BOMZH5_FROM_NIGHT = 4
freeze_active = False
bomzh5_timer = 0.0
next_bomzh5_time = random.randint(35000, 60000)
freeze_ms = 0.0
FREEZE_GRACE_MS = 400.0
freeze_anchor = (0, 0)
freeze_msg = ""
freeze_msg_ms = 0

def freeze_total_ms():
    return max(3000, 7000 - current_night * 500)

def schedule_bomzh5():
    global next_bomzh5_time
    next_bomzh5_time = random.randint(35000, 60000)

# Cameras
CAM_NAMES = ["CAM 1", "CAM 2", "CAM 3", "CAM 4", "CAM 5", "CAM 6"]
current_cam = "CAM 1"
broken_cams = set()

# Panel
panel_health = 100.0
panel_faults = [0, 0, 0, 0]
PANEL_LIGHTS = [
    (150, 200, 25, 120, 180),
    (350, 200, 25, 320, 180),
    (150, 400, 25, 120, 380),
    (350, 400, 25, 320, 380)
]
PANEL_X, PANEL_Y = 340, 110
PANEL_S = 1.2
panel_damage_timer = 0.0

# Placeholders
office_bg = pygame.Surface((WIDTH, HEIGHT))
office_bg.fill((60, 60, 65))
corridor_bg = pygame.Surface((WIDTH, HEIGHT))
corridor_bg.fill((20, 20, 25))
panel_img = pygame.Surface((600, 500))
panel_img.fill((80, 80, 90))

camera_images = {c: pygame.Surface((840, 520)) for c in CAM_NAMES}
for c in camera_images:
    camera_images[c].fill((30, 30, 35))

dark_layer = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
dark_layer.fill((0, 0, 0, 235))
light_mask = pygame.Surface((300, 300), pygame.SRCALPHA)
pygame.draw.circle(light_mask, (255, 255, 255, 255), (150, 150), 150)

bomzh_frames = [pygame.Surface((80, 120)) for _ in range(3)]
for f in bomzh_frames:
    f.fill((150, 50, 50))
bomzh3_frames = [pygame.Surface((60, 100)) for _ in range(3)]
for f in bomzh3_frames:
    f.fill((100, 100, 50))
bomzh4_frames = [pygame.Surface((70, 110)) for _ in range(3)]
for f in bomzh4_frames:
    f.fill((80, 80, 120))

def play_sound(name):
    pass

def stop_ambient():
    pass

class OpenCVVideo:
    def __init__(self, path):
        self.active = True
    def draw(self, surf, pos):
        self.active = False
    def close(self):
        pass

win_video = None

def draw_button(text, x, y, w, h, inactive_color, active_color, hold=False):
    mouse_pos = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()[0]
    rect = pygame.Rect(x, y, w, h)
    active = rect.collidepoint(mouse_pos)
    
    col = active_color if active else inactive_color
    pygame.draw.rect(screen, col, rect, border_radius=6)
    
    t_surf = font.render(text, True, WHITE)
    screen.blit(t_surf, t_surf.get_rect(center=rect.center))
    
    if hold:
        return active and click
    return active and click

def is_lit(mx, my, cx, cy):
    dist_sq = (mx - cx)**2 + (my - cy)**2
    return dist_sq <= 150**2

def flash_on():
    return not power_out

def draw_bomzh(frames, idx, x, y, h, col):
    surf = frames[idx % len(frames)]
    screen.blit(surf, (x, y))

def draw_door_alert(pos, is_office):
    pass

def draw_batteries(x, y):
    b_col = GREEN if battery > 50 else (YELLOW if battery > 20 else RED)
    pygame.draw.rect(screen, b_col, (x, y, int(battery * 2), 25), border_radius=4)
    screen.blit(cam_font.render(f"PWR: {int(battery)}%", True, BLACK), (x + 10, y + 3))

def draw_power_banner():
    txt = title_font.render("POWER OUTAGE!", True, RED)
    screen.blit(txt, txt.get_rect(center=(WIDTH // 2, HEIGHT // 2)))

def open_cameras():
    global game_state
    game_state = "cameras"

def close_cameras():
    global game_state
    game_state = "game"

def change_cam(name):
    global current_cam
    current_cam = name

def use_shocker():
    global battery
    if battery > 5:
        battery -= 5.0
        play_sound("shocker")

def repair_cam(c_name, dt):
    if c_name in broken_cams:
        broken_cams.remove(c_name)

def repair_door(dt):
    global door_health
    door_health = min(100.0, door_health + dt * 0.02)

def damage_panel(amount):
    global panel_health
    panel_health = max(0.0, panel_health - amount * 10)

def click_panel_light(idx):
    if panel_faults[idx] > 0:
        panel_faults[idx] -= 1

def bomzh3_pos():
    return (WIDTH // 2 - 30, HEIGHT // 2 - 50, 100)

def scare_bomzh3():
    global bomzh3_active, bomzh3_progress
    bomzh3_active = False
    bomzh3_progress = 0.0

# Main Loop
running = True
while running:
    dt = clock.tick(60)
    mouse_pos = pygame.mouse.get_pos()
    mouse_clicked = False

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                mouse_clicked = True

    # Menu State
    if game_state == "menu":
        screen.fill(DARK_GRAY)
        title = title_font.render("5 NIGHTS AT CHEKUN'S", True, WHITE)
        screen.blit(title, title.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 100)))
        
        if draw_button("START GAME", WIDTH // 2 - 150, HEIGHT // 2, 300, 60, GRAY, GREEN):
            game_state = "game"
            hours_passed = 0
            battery = 100.0
            power_out = False
            door_health = 100.0
        
        pygame.display.flip()
        continue

    # Between Nights
    if game_state == "between_nights":
        screen.fill(DARK_GRAY)
        txt = title_font.render(f"NIGHT {current_night} COMPLETED", True, GREEN)
        screen.blit(txt, txt.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 50)))
        
        if draw_button("NEXT NIGHT", WIDTH // 2 - 150, HEIGHT // 2 + 30, 300, 60, GRAY, BLUE):
            current_night += 1
            game_state = "game"
            hours_passed = 0
            battery = 100.0
            power_out = False
            door_health = 100.0
        
        pygame.display.flip()
        continue

    # Game Loop Logic
    if game_state in ("game", "corridor", "cameras", "panel"):
        night_timer += dt
        if night_timer >= 60000:
            night_timer = 0
            hours_passed += 1

        if not power_out:
            drain = 0.0005 * dt
            if game_state == "cameras": drain *= 1.5
            if game_state == "corridor": drain *= 1.2
            battery = max(0.0, battery - drain)
            if battery <= 0:
                power_out = True
                stop_ambient()
                play_sound("power_out")

        # Bum 1 logic
        if not power_out:
            if not bomzh_active:
                bomzh_timer += dt
                if bomzh_timer >= next_bomzh_time:
                    bomzh_active = True
                    bomzh_timer = 0
                    play_sound("bomzh_arrive")
            else:
                if door_health <= 0:
                    game_state = "game_over"
                else:
                    door_health -= dt * 0.003

        # Bum 2 logic
        if current_night >= BOMZH2_FROM_NIGHT and not power_out:
            if not bomzh2_active:
                bomzh2_timer += dt
                if bomzh2_timer >= next_bomzh2_time:
                    bomzh2_active = True
                    bomzh2_timer = 0
                    current_bomzh2_cam = bomzh2_path[0]
                    bomzh2_path_index = 0
                    play_sound("bomzh2_arrive")
            else:
                if current_bomzh2_cam == "CAM 6":
                    steal_timer_2 += dt
                    if steal_timer_2 >= max_steal_time:
                        game_state = "game_over"
                else:
                    steal_timer_2 = 0
                    bomzh2_timer += dt
                    if bomzh2_timer >= 10000:
                        bomzh2_path_index += 1
                        if bomzh2_path_index < len(bomzh2_path):
                            current_bomzh2_cam = bomzh2_path[bomzh2_path_index]
                        bomzh2_timer = 0
                        play_sound("bomzh2_move")

        # Bum 3 logic
        if current_night >= BOMZH3_FROM_NIGHT and not power_out:
            if not bomzh3_active:
                bomzh3_timer += dt
                if bomzh3_timer >= next_bomzh3_time:
                    bomzh3_active = True
                    bomzh3_timer = 0
                    bomzh3_progress = 0.0
                    bomzh3_scare = 0
                    play_sound("bomzh3_arrive")
            else:
                if game_state == "corridor":
                    if is_lit(mouse_pos[0], mouse_pos[1], WIDTH // 2, HEIGHT // 2):
                        bomzh3_scare += dt
                        if bomzh3_scare >= SCARE_MS:
                            scare_bomzh3()
                            play_sound("bomzh3_scare")
                    else:
                        bomzh3_scare = max(0, bomzh3_scare - dt // 2)
                
                approach_speed = 0.00003 + (current_night - 1) * 0.000008
                bomzh3_progress += dt * approach_speed
                if bomzh3_progress >= 1.0:
                    bomzh3_progress = 1.0
                    panel_damage_timer += dt
                    if panel_damage_timer >= 2000:
                        panel_damage_timer = 0
                        damage_panel(1)
                        play_sound("panel_hit")
                        if panel_health <= 0:
                            power_out = True
                            stop_ambient()
                            play_sound("power_out")

        # Bum 4 logic
        if current_night >= BOMZH4_FROM_NIGHT and not power_out:
            if not bomzh4_active:
                bomzh4_timer += dt
                if bomzh4_timer >= next_bomzh4_time:
                    bomzh4_active = True
                    bomzh4_timer = 0
                    bomzh4_index = 0
                    bomzh4_move_timer = 0
                    bomzh4_door_timer = 0
                    play_sound("bomzh4_arrive")
            else:
                is_watched = (game_state == "cameras" and current_cam == bomzh4_cam())
                if is_watched:
                    bomzh4_move_timer = 0
                    if bomzh4_index == len(BOMZH4_ROUTE) - 1:
                        bomzh4_door_timer = 0
                else:
                    if bomzh4_index < len(BOMZH4_ROUTE) - 1:
                        bomzh4_move_timer += dt
                        if bomzh4_move_timer >= bomzh4_move_ms():
                            bomzh4_move_timer = 0
                            bomzh4_index += 1
                            play_sound("bomzh4_move")
                    else:
                        bomzh4_door_timer += dt
                        if bomzh4_door_timer >= bomzh4_door_ms():
                            game_state = "game_over"

        # Bum 5 logic
        if current_night >= BOMZH5_FROM_NIGHT and not power_out:
            if freeze_msg_ms > 0:
                freeze_msg_ms -= dt
            if not freeze_active:
                bomzh5_timer += dt
                if bomzh5_timer >= next_bomzh5_time:
                    freeze_active = True
                    freeze_ms = 0
                    freeze_anchor = mouse_pos
                    play_sound("siren")
            else:
                freeze_ms += dt
                moved = (pygame.mouse.get_rel() != (0, 0) or mouse_clicked)
                if moved and freeze_ms > FREEZE_GRACE_MS:
                    freeze_active = False
                    freeze_msg = "fail"
                    freeze_msg_ms = 3000
                    door_health = max(0, door_health - 30)
                    damage_panel(2)
                    play_sound("bomzh5_jump")
                    schedule_bomzh5()
                elif freeze_ms >= freeze_total_ms():
                    freeze_active = False
                    freeze_msg = "ok"
                    freeze_msg_ms = 2500
                    play_sound("bomzh5_leave")
                    schedule_bomzh5()

        if hours_passed >= 6:
            if current_night >= 5:
                win_video = OpenCVVideo("win.mp4") if os.path.exists("win.mp4") else None
                game_state = "win_video"
            else:
                game_state = "between_nights"

    # Rendering
    if game_state == "game":
        screen.blit(office_bg, (0, 0))
        
        pygame.draw.rect(screen, BLUE, chekun_rect, border_radius=8)
        screen.blit(font.render("CHEKUN", True, WHITE), (chekun_rect.x + 35, chekun_rect.centery - 15))

        door_col = RED if door_health < 40 else (YELLOW if door_health < 75 else GREEN)
        pygame.draw.rect(screen, door_col, (20, 20, 220, 30), border_radius=4)
        screen.blit(cam_font.render(f"Door: {int(door_health)}%", True, BLACK), (30, 24))

        if bomzh_active:
            draw_bomzh(bomzh_frames, current_frame_index, 140, 620, 260, RED)
            screen.blit(cam_font.render("BUM AT DOOR!", True, RED), (20, 60))

        draw_door_alert((20, 95), True)
        draw_batteries(WIDTH - 250, 20)

        if draw_button("Cameras", 20, HEIGHT - 70, 180, 50, GRAY, BLUE):
            if not power_out:
                open_cameras()
        if draw_button("Corridor ->", WIDTH - 200, HEIGHT - 70, 180, 50, GRAY, RED):
            game_state = "corridor"
        if draw_button("Panel", WIDTH - 400, HEIGHT - 70, 180, 50, GRAY, YELLOW):
            game_state = "panel"

        if pygame.mouse.get_pressed()[0] and pygame.Rect(20, 20, 220, 30).collidepoint(mouse_pos):
            repair_door(dt)

        if power_out:
            screen.blit(dark_layer, (0, 0))
            draw_power_banner()

    elif game_state == "corridor":
        screen.blit(corridor_bg, (0, 0))
        if bomzh3_active:
            bx, bfeet, bh = bomzh3_pos()
            draw_bomzh(bomzh3_frames, int(bomzh3_progress * 10), bx, bfeet, bh, (100, 100, 80))

        if draw_button("<- Office", 20, HEIGHT - 70, 180, 50, GRAY, RED):
            game_state = "game"

        dark_layer.fill((0, 0, 0, 235))
        if flash_on():
            dark_layer.blit(light_mask, (mouse_pos[0] - 150, mouse_pos[1] - 150), special_flags=pygame.BLEND_RGBA_SUB)
        screen.blit(dark_layer, (0, 0))
        draw_batteries(WIDTH - 250, 20)

    elif game_state == "cameras":
        screen.fill(BLACK)
        screen.blit(camera_images[current_cam], (220, 100))

        if current_cam in broken_cams:
            broken_surf = pygame.Surface((840, 520))
            broken_surf.fill((20, 20, 20))
            screen.blit(broken_surf, (220, 100))
            screen.blit(title_font.render("CAMERA BROKEN!", True, RED), (460, 320))
            if draw_button("Repair (Hold)", 480, 390, 280, 50, GRAY, GREEN, hold=True):
                repair_cam(current_cam, dt)
        else:
            if current_cam == "CAM 1" and bomzh_active:
                draw_bomzh(bomzh_frames, current_frame_index, 620, 520, 300, RED)
            elif current_cam == current_bomzh2_cam and bomzh2_active:
                draw_bomzh(bomzh_frames, current_frame_index, 620, 520, 280, BLUE)
            elif bomzh4_active and current_cam == bomzh4_cam():
                draw_bomzh(bomzh4_frames, 0, 620, 520, 290, YELLOW)

        for i, c_name in enumerate(CAM_NAMES):
            col = RED if c_name in broken_cams else BLUE
            if draw_button(c_name, WIDTH - 200, 100 + i * 65, 180, 55, GRAY, col):
                change_cam(c_name)

        if draw_button("Close", 20, HEIGHT - 70, 180, 50, GRAY, RED):
            close_cameras()
        if draw_button("⚡ SHOCK", 20, HEIGHT - 140, 180, 50, GRAY, RED):
            use_shocker()

        draw_batteries(20, 20)
        draw_door_alert((20, 130), False)

    elif game_state == "panel":
        screen.fill((40, 40, 45))
        screen.blit(panel_img, (PANEL_X, PANEL_Y))

        for i, (cx, cy, r, dx, dy) in enumerate(PANEL_LIGHTS):
            st = panel_faults[i]
            lcol = GREEN if st == 0 else (YELLOW if st == 1 else RED)
            pygame.draw.circle(screen, lcol, (PANEL_X + int(dx * PANEL_S), PANEL_Y + int(dy * PANEL_S)), int(12 * PANEL_S))
            
            if mouse_clicked:
                dist = (mouse_pos[0] - (PANEL_X + int(cx * PANEL_S)))**2 + (mouse_pos[1] - (PANEL_Y + int(cy * PANEL_S)))**2
                if dist < (r * PANEL_S)**2:
                    click_panel_light(i)

        screen.blit(title_font.render(f"Panel: {int(panel_health)}%", True, WHITE), (WIDTH // 2 - 120, 40))
        if draw_button("<- Office", 20, HEIGHT - 70, 180, 50, GRAY, RED):
            game_state = "game"

    elif game_state == "game_over":
        screen.fill(BLACK)
        over_text = title_font.render("GAME OVER", True, RED)
        screen.blit(over_text, over_text.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 50)))
        if draw_button("Main Menu", WIDTH // 2 - 150, HEIGHT // 2 + 30, 300, 60, GRAY, RED):
            game_state = "menu"

    elif game_state == "win_video":
        screen.fill(BLACK)
        if win_video:
            win_video.draw(screen, (0, 0))
            if not win_video.active:
                win_video.close()
                win_video = None
                game_state = "between_nights"
        else:
            win_text = title_font.render("ALL NIGHTS COMPLETED!", True, GREEN)
            screen.blit(win_text, win_text.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 50)))
            if draw_button("Main Menu", WIDTH // 2 - 150, HEIGHT // 2 + 30, 300, 60, GRAY, RED):
                game_state = "menu"

    if game_state in ("game", "cameras", "corridor", "panel"):
        time_str = f"{6 + hours_passed}:00 AM" if hours_passed < 6 else "12:00 AM"
        t_surf = font.render(time_str, True, WHITE)
        screen.blit(t_surf, (WIDTH - 150 - t_surf.get_width(), 20))

    pygame.display.flip()

pygame.quit()
sys.exit()